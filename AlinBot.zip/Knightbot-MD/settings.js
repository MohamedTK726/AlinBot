const settings = {
  packname: 'Alin bot',
  author: '‎',
  botName: "Alin bot",
  botOwner: 'MohamedTawfik', // Your name
  ownerNumber: '201005560325', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.7",
  updateZipUrl: "",
};

module.exports = settings;
